from setuptools import setup

setup(
    name='ftSoundBarCtrl',
    version='1.1',
    packages=['ftcSoundBar'],
    url='',
    license='GNU General Public License v3.0',
    author='Bloeckchengrafik',
    author_email='ftpi@gmx.de',
    description='The ftcSoundBar Python Libary'
)
